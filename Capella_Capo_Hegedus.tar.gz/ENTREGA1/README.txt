Grupo: MDK
Miembros: Bartomeu Capó Salas, Pau Capellá Ballester, Emanuel Hegedus

La práctica carece de warnings, han sido revisados y eliminados.
Sin restricciones conocidas.
La sintaxis específica para cada programa es la recomendada por las diapositivas, pero si no es escrita adecuadamente, saltará un error con las instrucciones necesarias.
No poner bien el nombre del disco puede que no esté siempre bien gestionado.
